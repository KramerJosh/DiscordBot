slackURL = process.env.SLACK_URL

const handler = async (event) => {
  try {
    fetch(slackURL), {
        method: 'post',
        header: {
            'Content-Type': 'application/json',
        },
        // body: JSON.stringify(event.Records),
        body: {
            "text": "TEST"
        },
    }
    console.log(event)
  } catch (e) {
    console.error(e);
  }  
};

module.exports = { handler };