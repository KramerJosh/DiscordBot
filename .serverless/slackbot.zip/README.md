# DiscordBot
Challenge 20

## TODO 
    
    Create new SNS topic
    Clean up routes a little in serverless.yaml
    